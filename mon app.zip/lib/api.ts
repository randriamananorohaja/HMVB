import { supabase } from './supabase';
import type { Member, Presence, PresenceStatus, Team, Training } from './types';

// Teams
export async function getTeam(): Promise<Team | null> {
  const { data, error } = await supabase
    .from('teams')
    .select('*')
    .single();

  if (error) {
    console.error('Error fetching team:', error);
    return null;
  }

  return data;
}

export async function updateTeam(id: string, updates: Partial<Team>) {
  const { data, error } = await supabase
    .from('teams')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('Error updating team:', error);
    return null;
  }

  return data;
}

// Members
export async function getMembers(): Promise<Member[]> {
  const { data, error } = await supabase
    .from('members')
    .select('*')
    .order('number');

  if (error) {
    console.error('Error fetching members:', error);
    return [];
  }

  return data || [];
}

export async function getMember(id: string): Promise<Member | null> {
  const { data, error } = await supabase
    .from('members')
    .select('*')
    .eq('id', id)
    .single();

  if (error) {
    console.error('Error fetching member:', error);
    return null;
  }

  return data;
}

export async function createMember(member: Partial<Member>) {
  const { data, error } = await supabase
    .from('members')
    .insert(member)
    .select()
    .single();

  if (error) {
    console.error('Error creating member:', error);
    return null;
  }

  return data;
}

export async function updateMember(id: string, updates: Partial<Member>) {
  const { data, error } = await supabase
    .from('members')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('Error updating member:', error);
    return null;
  }

  return data;
}

export async function deleteMember(id: string) {
  const { error } = await supabase
    .from('members')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Error deleting member:', error);
    return false;
  }

  return true;
}

// Trainings
export async function getTrainings(): Promise<Training[]> {
  const { data, error } = await supabase
    .from('trainings')
    .select('*')
    .order('date', { ascending: false });

  if (error) {
    console.error('Error fetching trainings:', error);
    return [];
  }

  return data || [];
}

export async function getTraining(id: string): Promise<Training | null> {
  const { data, error } = await supabase
    .from('trainings')
    .select('*')
    .eq('id', id)
    .single();

  if (error) {
    console.error('Error fetching training:', error);
    return null;
  }

  return data;
}

export async function createTraining(training: Partial<Training>) {
  const { data, error } = await supabase
    .from('trainings')
    .insert(training)
    .select()
    .single();

  if (error) {
    console.error('Error creating training:', error);
    return null;
  }

  return data;
}

export async function updateTraining(id: string, updates: Partial<Training>) {
  const { data, error } = await supabase
    .from('trainings')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('Error updating training:', error);
    return null;
  }

  return data;
}

export async function deleteTraining(id: string) {
  const { error } = await supabase
    .from('trainings')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Error deleting training:', error);
    return false;
  }

  return true;
}

// Presences
export async function getPresences(trainingId: string): Promise<Presence[]> {
  const { data, error } = await supabase
    .from('presences')
    .select('*')
    .eq('training_id', trainingId);

  if (error) {
    console.error('Error fetching presences:', error);
    return [];
  }

  return data || [];
}

export async function getMemberPresences(memberId: string): Promise<Presence[]> {
  const { data, error } = await supabase
    .from('presences')
    .select('*, trainings(*)')
    .eq('member_id', memberId);

  if (error) {
    console.error('Error fetching member presences:', error);
    return [];
  }

  return data || [];
}

export async function createPresence(presence: Partial<Presence>) {
  const { data, error } = await supabase
    .from('presences')
    .insert(presence)
    .select()
    .single();

  if (error) {
    console.error('Error creating presence:', error);
    return null;
  }

  return data;
}

export async function updatePresence(id: string, updates: Partial<Presence>) {
  const { data, error } = await supabase
    .from('presences')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('Error updating presence:', error);
    return null;
  }

  return data;
}

export async function recordPresence(
  trainingId: string,
  memberId: string,
  status: PresenceStatus,
  time?: string
) {
  const { data, error } = await supabase
    .from('presences')
    .upsert(
      {
        training_id: trainingId,
        member_id: memberId,
        status,
        time,
      },
      {
        onConflict: 'training_id,member_id',
      }
    )
    .select()
    .single();

  if (error) {
    console.error('Error recording presence:', error);
    return null;
  }

  return data;
}

// Avatar upload
export async function uploadAvatar(memberId: string, uri: string): Promise<string | null> {
  const fileName = `${memberId}/${Date.now()}.jpg`;
  
  // Read file as ArrayBuffer
  const response = await fetch(uri);
  const blob = await response.blob();
  const arrayBuffer = await blob.arrayBuffer();
  
  const { data, error } = await supabase.storage
    .from('avatars')
    .upload(fileName, arrayBuffer, {
      contentType: 'image/jpeg',
      upsert: true,
    });

  if (error) {
    console.error('Error uploading avatar:', error);
    return null;
  }

  const { data: { publicUrl } } = supabase.storage
    .from('avatars')
    .getPublicUrl(fileName);

  return publicUrl;
}

export async function deleteAvatar(path: string) {
  const { error } = await supabase.storage
    .from('avatars')
    .remove([path]);

  if (error) {
    console.error('Error deleting avatar:', error);
    return false;
  }

  return true;
}
