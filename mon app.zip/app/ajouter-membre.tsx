import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Colors, Radius } from '@/constants/theme';
import { POSITIONS } from '@/constants/data';
import { Header } from '@/components/volley/Header';
import { PrimaryButton } from '@/components/volley/PrimaryButton';
import { IconSymbol } from '@/components/ui/icon-symbol';

export default function AjouterMembreScreen() {
  const router = useRouter();
  const [lastName, setLastName] = useState('');
  const [firstName, setFirstName] = useState('');
  const [number, setNumber] = useState('');
  const [position, setPosition] = useState(POSITIONS[0]);
  const [phone, setPhone] = useState('');
  const [showPositions, setShowPositions] = useState(false);

  const handleSave = () => {
    if (!lastName || !firstName) {
      Alert.alert('Erreur', 'Nom et prénom sont obligatoires');
      return;
    }
    Alert.alert('Succès', 'Membre ajouté avec succès', [
      { text: 'OK', onPress: () => router.back() },
    ]);
  };

  return (
    <View style={styles.container}>
      <Header title="Ajouter un membre" showBack />
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        {/* Photo */}
        <TouchableOpacity style={styles.photoBox}>
          <IconSymbol name="camera.fill" size={32} color={Colors.light.textMuted} />
          <Text style={styles.photoText}>Ajouter une photo</Text>
        </TouchableOpacity>

        <Field label="Nom *" value={lastName} onChange={setLastName} placeholder="Rakoto" />
        <Field label="Prénom *" value={firstName} onChange={setFirstName} placeholder="Andry" />
        <Field
          label="Numéro de maillot"
          value={number}
          onChange={setNumber}
          placeholder="7"
          keyboard="numeric"
        />

        <Text style={styles.label}>Position</Text>
        <TouchableOpacity
          style={styles.select}
          onPress={() => setShowPositions(!showPositions)}
        >
          <Text style={styles.selectText}>{position}</Text>
          <IconSymbol name="chevron.right" size={18} color={Colors.light.textMuted} />
        </TouchableOpacity>
        {showPositions && (
          <View style={styles.dropdown}>
            {POSITIONS.map((p) => (
              <TouchableOpacity
                key={p}
                style={styles.dropdownItem}
                onPress={() => {
                  setPosition(p);
                  setShowPositions(false);
                }}
              >
                <Text
                  style={[
                    styles.dropdownText,
                    p === position && { color: Colors.light.primary, fontWeight: '600' },
                  ]}
                >
                  {p}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        <Field
          label="Téléphone"
          value={phone}
          onChange={setPhone}
          placeholder="+261 34 12 34 567"
          keyboard="phone-pad"
        />

        <PrimaryButton title="Ajouter le membre" onPress={handleSave} style={{ marginTop: 24 }} />
      </ScrollView>
    </View>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  keyboard,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  keyboard?: any;
}) {
  return (
    <View style={{ marginBottom: 16 }}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={styles.input}
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor={Colors.light.textMuted}
        keyboardType={keyboard}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.light.background },
  photoBox: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: Colors.light.card,
    borderWidth: 2,
    borderColor: Colors.light.border,
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    marginBottom: 24,
  },
  photoText: { fontSize: 11, color: Colors.light.textMuted, marginTop: 4 },
  label: {
    fontSize: 13,
    fontWeight: '600',
    color: Colors.light.textSecondary,
    marginBottom: 6,
  },
  input: {
    backgroundColor: Colors.light.card,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.light.border,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    color: Colors.light.text,
  },
  select: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.light.card,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.light.border,
    paddingHorizontal: 14,
    paddingVertical: 14,
    marginBottom: 16,
  },
  selectText: { fontSize: 15, color: Colors.light.text },
  dropdown: {
    backgroundColor: Colors.light.card,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.light.border,
    marginTop: -12,
    marginBottom: 16,
    overflow: 'hidden',
  },
  dropdownItem: { paddingHorizontal: 14, paddingVertical: 12 },
  dropdownText: { fontSize: 15, color: Colors.light.text },
});
